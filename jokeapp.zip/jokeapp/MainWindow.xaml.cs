﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Newtonsoft.Json;
namespace jokeapp
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<Joke> Jokes { get; private set; } = new ObservableCollection<Joke>();
        private ObservableCollection<Joke> _filteredJokes = new ObservableCollection<Joke>();

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
            LoadJokes();
        }

        private async void LoadJokes()
        {
            var jokes = await JokeService.GetJokesAsync();
            foreach (var joke in jokes)
            {
                Jokes.Add(joke);
            }
            _filteredJokes = new ObservableCollection<Joke>(Jokes);
            ListViewJokes.ItemsSource = _filteredJokes;
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string filter = SearchBox.Text.ToLower();
            _filteredJokes.Clear();
            foreach (var joke in Jokes.Where(j => j.Setup.ToLower().Contains(filter)))
            {
                _filteredJokes.Add(joke);
            }
        }

        private void ListViewJokes_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (ListViewJokes.SelectedItem is Joke selectedJoke)
            {
                var detailWindow = new DetailWindow(selectedJoke);
                detailWindow.ShowDialog();
            }
        }
    }
    public class Joke
    {
        public string Setup { get; set; }
        public string Delivery { get; set; }
    }

    public static class JokeService
    {
        private static readonly HttpClient _httpClient = new HttpClient();

        public static async Task<Joke[]> GetJokesAsync()
        {
            string url = "https://v2.jokeapi.dev/joke/Any?type=twopart&amount=10";
            var response = await _httpClient.GetStringAsync(url);
            var jokes = JsonConvert.DeserializeObject<JokeApiResponse>(response); // Используем Newtonsoft.Json
            return jokes != null ? jokes.Jokes : new Joke[0];
        }
    }

    public class JokeApiResponse
    {
        public Joke[] Jokes { get; set; }
    }


}
